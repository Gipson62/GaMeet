## 1. Commande pour démarrer:
Depuis le répertoire `website/`, exécuter la commande suivante :

```bash
npm install && npm run dev
```