// Configuration de l'environnement
// Pour l'émulateur Android, localhost est accessible via 10.0.2.2
// Pour un appareil physique, utilisez l'adresse IP locale de votre machine (ex: 192.168.1.x)

// Configuration pour gsm perso (indiquer l'adresse IP de votre ordi)
export const BASE_URL = "http://192.168.1.38:3001";
export const API_URL = `${BASE_URL}/v1`;
