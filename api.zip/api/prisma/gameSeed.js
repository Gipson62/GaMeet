const BINDING_OF_ISAAC = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "the_binding_of_isaac_grid.png",
    banner: "the_binding_of_isaac_banner.png",
    logo: "the_binding_of_isaac_logo.png"
}
const THE_WITCHER_3 = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "the_witcher_3_grid.png",
    banner: "the_witcher_3_banner.png",
    logo: "the_witcher_3_logo.png"
}
const DESTINY_2 = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "destiny_2_grid.jpg",
    banner: "destiny_2_banner.jpg",
    logo: "destiny_2_logo.png"
}
const WAR_THUNDER = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "war_thunder_grid.jpg",
    banner: "war_thunder_banner.jpg",
    logo: "war_thunder_logo.png"
}
const LEAGUE_OF_LEGENDS = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "league_of_legends_grid.png",
    banner: "league_of_legends_banner.jpg",
    logo: "league_of_legends_logo.png"
}
const RAINBOW_SIX_SIEGE = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "rainbow_six_siege_grid.jpg",
    banner: "rainbow_six_siege_banner.jpg",
    logo: "rainbow_six_siege_logo.png"
}
const COUNTER_STRIKE_2 = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "counter_strike_2_grid.jpg",
    banner: "counter_strike_2_banner.jpg",
    logo: "counter_strike_2_logo.png"
}
const LOST_ARK = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "lost_ark_grid.jpg",
    banner: "lost_ark_banner.jpg",
    logo: "lost_ark_logo.png"
}
const MARIO_KART_8 = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "mario_kart_8_grid.jpg",
    banner: "mario_kart_8_banner.jpg",
    logo: "mario_kart_8_logo.png"
}
const WORLD_OF_WARCRAFT = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "world_of_warcraft_grid.jpg",
    banner: "world_of_warcraft_banner.jpg",
    logo: "world_of_warcraft_logo.png"
}
const YOMI_HUSTLE = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "yomi_hustle_grid.jpg",
    banner: "yomi_hustle_banner.jpg",
    logo: "yomi_hustle_logo.png"
}
const CLAIR_OBSCURE = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "clair_obscure_grid.jpg",
    banner: "clair_obscure_banner.jpg",
    logo: "clair_obscure_logo.png"
}
const DRAGON_DOGMA_ONLINE = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "dragon_dogma_online_grid.jpg",
    banner: "dragon_dogma_online_banner.jpg",
    logo: "dragon_dogma_online_logo.png"
}
const APEX_LEGENDS = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "apex_legends_grid.jpg",
    banner: "apex_legends_banner.jpg",
    logo: "apex_legends_logo.png"
}
const BLOODBORNE = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "bloodborne_grid.jpg",
    banner: "bloodborne_banner.png",
    logo: "bloodborne_logo.png"
}
const CIV_VI = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "civ_vi_grid.jpg",
    banner: "civ_vi_banner.jpg",
    logo: "civ_vi_logo.png"
}
const DARK_SOULS_3 = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "dark_souls_3_grid.jpg",
    banner: "dark_souls_3_banner.jpg",
    logo: "dark_souls_3_logo.png"
}
const ELDEN_RING = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "elden_ring_grid.jpg",
    banner: "elden_ring_banner.jpg",
    logo: "elden_ring_logo.png"
}
const ENLISTED = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "enlisted_grid.jpg",
    banner: "enlisted_banner.jpg",
    logo: "enlisted_logo.png"
}
const FFXIV = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "ffxiv_grid.jpg",
    banner: "ffxiv_banner.jpg",
    logo: "ffxiv_logo.png"
}
const FIRE_EMBLEM_THREE_HOUSES = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "fire_emblem_three_houses_grid.jpg",
    banner: "fire_emblem_three_houses_banner.png",
    logo: "fire_emblem_three_houses_logo.png"
}
const FORTNITE = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "fortnite_grid.jpg",
    banner: "fortnite_banner.jpg",
    logo: "fortnite_logo.png"
}
const GUILD_WARS_2 = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "gw_2_grid.jpg",
    banner: "gw_2_banner.jpg",
    logo: "gw_2_logo.png"
}
const HADES = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "hades_grid.jpg",
    banner: "hades_banner.jpg",
    logo: "hades_logo.png"
}
const MINECRAFT = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "minecraft_grid.jpg",
    banner: "minecraft_banner.jpg",
    logo: "minecraft_logo.png"
}
const MOUNT_BLADE_2 = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "mount_blade_2_grid.jpg",
    banner: "mount_blade_2_banner.jpg",
    logo: "mount_blade_2_logo.ico"
}
const OVERWATCH_2 = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "overwatch_2_grid.jpg",
    banner: "overwatch_2_banner.jpg",
    logo: "overwatch_2_logo.png"
}
const TESO = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "teso_grid.jpg",
    banner: "teso_banner.jpg",
    logo: "teso_logo.png"
}
const VALORANT = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "valorant_grid.jpg",
    banner: "valorant_banner.jpg",
    logo: "valorant_logo.png"
}
const KINGDOM_HEARTS_2 = {
    grid_id: null,
    banner_id: null,
    logo_id: null,
    grid: "kingdom_hearts_2_grid.jpg",
    banner: "kingdom_hearts_2_banner.jpg",
    logo: "kingdom_hearts_2_logo.png"
}

const seedAllGames = async (prisma) => {
    await prisma.tag.createMany({
        data: [
            { name: "Action" },
            { name: "Adventure" },
            { name: "RPG" },
            { name: "Indie" },
            { name: "Platformer" },
            { name: "Puzzle" },
            { name: "Sports" },
            { name: "Stratégie" },
            { name: "Simulation" },
            { name: "Difficile" },
            { name: "Multijoueur" },
            { name: "FPS" },
            { name: "MOBA" },
            { name: "Roguelike" },
            { name: "Horreur" },
            { name: "Open-World" },
            { name: "Story-Rich" },
            { name: "Looter-Shooter" },
            { name: "PvP" },
            { name: "Co-op" },
            { name: "Tactical" },
            { name: "Soulslike" },
            { name: "JRPG" },
            { name: "MMORPG" },
            { name: "MMO" },
            { name: "Battle Royale" },
            { name: "Hero Shooter" },
            { name: "Tactical Shooter" },
            { name: "Survival" },
            { name: "Sandbox" },
            { name: "Building" },
            { name: "Crafting" },
            { name: "Creative" },
            { name: "Turn-Based" },
            { name: "Tactical RPG" },
            { name: "Hack-and-Slash" },
            { name: "Isometric" },
            { name: "4X" },
            { name: "Medieval" },
            { name: "Fantasy" },
            { name: "Sci-Fi" },
            { name: "Singleplayer" },
            { name: "Shooter" },
            { name: "Esports" },
        ],
        skipDuplicates: true,
    });

    // Array to collect all game IDs
    const gameIds = [];

    BINDING_OF_ISAAC.grid_id = await prisma.photo.create({
        data: {
            url: BINDING_OF_ISAAC.grid,
        },
        select: { id: true }
    });
    BINDING_OF_ISAAC.banner_id = await prisma.photo.create({
        data: {
            url: BINDING_OF_ISAAC.banner,
        },
        select: { id: true }
    });
    BINDING_OF_ISAAC.logo_id = await prisma.photo.create({
        data: {
            url: BINDING_OF_ISAAC.logo,
        },
        select: { id: true }
    });
    const bindingOfIsaac = await prisma.game.create({
        data: {
            name: "The Binding of Isaac: Rebirth",
            studio: "Nicalis, Inc.",
            publisher: "Nicalis, Inc.",
            description: "The Binding of Isaac: Rebirth is a roguelike dungeon crawler video game designed by Edmund McMillen and developed and published by Nicalis, Inc. It is a remake of the original The Binding of Isaac game, which was released in 2011. The game features randomly generated levels, items, and enemies, providing a unique experience with each playthrough. Players control Isaac, a young boy who must navigate through his mother's basement to escape her attempts to sacrifice him, battling grotesque monsters and bosses along the way.",
            release_date: new Date("2014-11-04"),
            platforms: "PC, Mac, Linux, PS4, PS Vita, Xbox One, Nintendo Switch",
            grid_id: BINDING_OF_ISAAC.grid_id.id,
            banner_id: BINDING_OF_ISAAC.banner_id.id,
            logo_id: BINDING_OF_ISAAC.logo_id.id,
            is_approved: true,
        },
    });
    gameIds.push(bindingOfIsaac.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: bindingOfIsaac.id, tag_name: "Roguelike" },
            { game_id: bindingOfIsaac.id, tag_name: "Indie" },
            { game_id: bindingOfIsaac.id, tag_name: "Action" },
            { game_id: bindingOfIsaac.id, tag_name: "Difficile" },
        ]
    });
    THE_WITCHER_3.grid_id = await prisma.photo.create({
        data: {
            url: THE_WITCHER_3.grid,
        },
        select: { id: true }
    });
    THE_WITCHER_3.banner_id = await prisma.photo.create({
        data: {
            url: THE_WITCHER_3.banner,
        },
        select: { id: true }
    });
    THE_WITCHER_3.logo_id = await prisma.photo.create({
        data: {
            url: THE_WITCHER_3.logo,
        },
        select: { id: true }
    });
    const witcher3 = await prisma.game.create({
        data: {
            name: "The Witcher 3: Wild Hunt",
            studio: "CD Projekt Red",
            publisher: "CD Projekt",
            description: "The Witcher 3: Wild Hunt is an action role-playing game developed by CD Projekt Red. It is the third installment in The Witcher series, based on the book series by Andrzej Sapkowski. Players assume the role of Geralt of Rivia, a monster hunter known as a Witcher, as he embarks on a quest to find his adopted daughter, Ciri, who is on the run from the Wild Hunt, a spectral cavalcade determined to capture her for her Elder Blood powers. The game features an open world environment, rich storytelling, and complex characters.",
            release_date: new Date("2015-05-19"),
            platforms: "PC, PS4, Xbox One, Nintendo Switch",
            grid_id: THE_WITCHER_3.grid_id.id,
            banner_id: THE_WITCHER_3.banner_id.id,
            logo_id: THE_WITCHER_3.logo_id.id,
            is_approved: true,
        },
    });
    gameIds.push(witcher3.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: witcher3.id, tag_name: "RPG" },
            { game_id: witcher3.id, tag_name: "Adventure" },
            { game_id: witcher3.id, tag_name: "Action" },
            { game_id: witcher3.id, tag_name: "Open-World" },
            { game_id: witcher3.id, tag_name: "Story-Rich" },
        ]
    });
    DESTINY_2.grid_id = await prisma.photo.create({
        data: {
            url: DESTINY_2.grid,
        },
        select: { id: true }
    });
    DESTINY_2.banner_id = await prisma.photo.create({
        data: {
            url: DESTINY_2.banner,
        },
        select: { id: true }
    });
    DESTINY_2.logo_id = await prisma.photo.create({
        data: {
            url: DESTINY_2.logo,
        },
        select: { id: true }
    });
    const destiny2 = await prisma.game.create({
        data: {
            name: "Destiny 2",
            studio: "Bungie",
            publisher: "Bungie",
            description: "Destiny 2 is an online-only multiplayer first-person shooter video game developed by Bungie. It is the sequel to the 2014 game Destiny and its subsequent expansions. In Destiny 2, players assume the role of Guardians, protectors of Earth's last safe city as they wield a power called Light to defend humanity against various alien threats. The game features both player versus environment (PvE) and player versus player (PvP) modes, with a focus on cooperative gameplay, raids, and competitive multiplayer matches.",
            release_date: new Date("2017-09-06"),
            platforms: "PC, PS4, PS5, Xbox One, Xbox Series X/S",
            grid_id: DESTINY_2.grid_id.id,
            banner_id: DESTINY_2.banner_id.id,
            logo_id: DESTINY_2.logo_id.id,
            is_approved: true,
        },
    });
    gameIds.push(destiny2.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: destiny2.id, tag_name: "FPS" },
            { game_id: destiny2.id, tag_name: "Multijoueur" },
            { game_id: destiny2.id, tag_name: "Looter-Shooter" },
            { game_id: destiny2.id, tag_name: "PvP" },
            { game_id: destiny2.id, tag_name: "Co-op" },
        ]
    });
    WAR_THUNDER.grid_id = await prisma.photo.create({
        data: {
            url: WAR_THUNDER.grid,
        },
        select: { id: true }
    });
    WAR_THUNDER.banner_id = await prisma.photo.create({
        data: {
            url: WAR_THUNDER.banner,
        },
        select: { id: true }
    });
    WAR_THUNDER.logo_id = await prisma.photo.create({
        data: {
            url: WAR_THUNDER.logo,
        },
        select: { id: true }
    });
    const warThunder = await prisma.game.create({
        data: {
            name: "War Thunder",
            studio: "Gaijin Entertainment",
            publisher: "Gaijin Entertainment",
            description: "War Thunder is a free-to-play vehicular combat multiplayer video game developed and published by Gaijin Entertainment. The game is set during the mid-20th century and features a wide range of military vehicles, including aircraft, tanks, and ships from various countries. Players can engage in battles across different theaters of war, participating in both player versus environment (PvE) and player versus player (PvP) modes. War Thunder emphasizes realistic gameplay mechanics, vehicle physics, and historical accuracy, offering an immersive experience for fans of military simulations.",
            release_date: new Date("2013-11-15"),
            platforms: "PC, PS4, PS5, Xbox One, Xbox Series X/S",
            grid_id: WAR_THUNDER.grid_id.id,
            banner_id: WAR_THUNDER.banner_id.id,
            logo_id: WAR_THUNDER.logo_id.id,
            is_approved: true,
        },
    });
    gameIds.push(warThunder.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: warThunder.id, tag_name: "Simulation" },
            { game_id: warThunder.id, tag_name: "Multijoueur" },
            { game_id: warThunder.id, tag_name: "PvP" },
            { game_id: warThunder.id, tag_name: "Action" },
        ]
    });
    LEAGUE_OF_LEGENDS.grid_id = await prisma.photo.create({
        data: {
            url: LEAGUE_OF_LEGENDS.grid,
        },
        select: { id: true }
    });
    LEAGUE_OF_LEGENDS.banner_id = await prisma.photo.create({
        data: {
            url: LEAGUE_OF_LEGENDS.banner,
        },
        select: { id: true }
    });
    LEAGUE_OF_LEGENDS.logo_id = await prisma.photo.create({
        data: {
            url: LEAGUE_OF_LEGENDS.logo,
        },
        select: { id: true }
    });
    const lol = await prisma.game.create({
        data: {
            name: "League of Legends",
            studio: "Riot Games",
            publisher: "Riot Games",
            description: "League of Legends (LoL) is a multiplayer online battle arena (MOBA) game developed and published by Riot Games. In League of Legends, players assume the role of a 'champion' with unique abilities and battle against a team of other players or computer-controlled champions. The primary objective is to destroy the opposing team's Nexus, a structure located within their base. The game features various modes, including ranked matches, casual games, and special events. League of Legends is known for its competitive esports scene, with numerous tournaments and leagues held worldwide.",
            release_date: new Date("2009-10-27"),
            platforms: "PC, Mac",
            grid_id: LEAGUE_OF_LEGENDS.grid_id.id,
            banner_id: LEAGUE_OF_LEGENDS.banner_id.id,
            logo_id: LEAGUE_OF_LEGENDS.logo_id.id,
            is_approved: true,
        },
    });
    gameIds.push(lol.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: lol.id, tag_name: "MOBA" },
            { game_id: lol.id, tag_name: "Multijoueur" },
            { game_id: lol.id, tag_name: "PvP" },
            { game_id: lol.id, tag_name: "Stratégie" },
        ]
    });
    RAINBOW_SIX_SIEGE.grid_id = await prisma.photo.create({
        data: {
            url: RAINBOW_SIX_SIEGE.grid,
        },
        select: { id: true }
    });
    RAINBOW_SIX_SIEGE.banner_id = await prisma.photo.create({
        data: {
            url: RAINBOW_SIX_SIEGE.banner,
        },
        select: { id: true }
    });
    RAINBOW_SIX_SIEGE.logo_id = await prisma.photo.create({
        data: {
            url: RAINBOW_SIX_SIEGE.logo,
        },
        select: { id: true }
    });
    const rainbow6 = await prisma.game.create({
        data: {
            name: "Tom Clancy's Rainbow Six Siege",
            studio: "Ubisoft Montreal",
            publisher: "Ubisoft",
            description: "Tom Clancy's Rainbow Six Siege is a tactical shooter video game developed by Ubisoft Montreal and published by Ubisoft. The game focuses on team-based gameplay, where players assume the roles of various operators from different counter-terrorism units around the world. Each operator has unique abilities and gadgets that can be used to breach, defend, or gather intelligence. The game features destructible environments, allowing players to create new lines of sight and entry points during matches. Rainbow Six Siege emphasizes strategy, communication, and coordination among team members, making it a popular choice for competitive esports.",
            release_date: new Date("2015-12-01"),
            platforms: "PC, PS4, PS5, Xbox One, Xbox Series X/S",
            grid_id: RAINBOW_SIX_SIEGE.grid_id.id,
            banner_id: RAINBOW_SIX_SIEGE.banner_id.id,
            logo_id: RAINBOW_SIX_SIEGE.logo_id.id,
            is_approved: true,
        },
    });
    gameIds.push(rainbow6.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: rainbow6.id, tag_name: "FPS" },
            { game_id: rainbow6.id, tag_name: "Tactical" },
            { game_id: rainbow6.id, tag_name: "Multijoueur" },
            { game_id: rainbow6.id, tag_name: "PvP" },
        ]
    });
    COUNTER_STRIKE_2.grid_id = await prisma.photo.create({
        data: {
            url: COUNTER_STRIKE_2.grid,
        },
        select: { id: true }
    });
    COUNTER_STRIKE_2.banner_id = await prisma.photo.create({
        data: {
            url: COUNTER_STRIKE_2.banner,
        },
        select: { id: true }
    });
    COUNTER_STRIKE_2.logo_id = await prisma.photo.create({
        data: {
            url: COUNTER_STRIKE_2.logo,
        },
        select: { id: true }
    });
    const counterStrike2 = await prisma.game.create({
        data: {
            name: "Counter-Strike 2",
            studio: "Valve Corporation",
            publisher: "Valve Corporation",
            description: "Counter-Strike 2 is the next evolution of the legendary Counter-Strike franchise, developed by Valve Corporation. Built on the Source 2 engine, CS2 brings updated graphics, improved gameplay mechanics, and enhanced networking. Players engage in intense 5v5 tactical shooter matches, choosing between terrorists and counter-terrorists. The game features classic maps reimagined with modern technology, dynamic smoke grenades that interact with the environment, and a new sub-tick system for more responsive gameplay. CS2 maintains the competitive depth that made Counter-Strike a staple of esports while introducing quality-of-life improvements and visual enhancements.",
            release_date: new Date("2023-09-27"),
            platforms: "PC",
            grid_id: COUNTER_STRIKE_2.grid_id.id,
            banner_id: COUNTER_STRIKE_2.banner_id.id,
            logo_id: COUNTER_STRIKE_2.logo_id.id,
            is_approved: true,
        },
    });
    gameIds.push(counterStrike2.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: counterStrike2.id, tag_name: "FPS" },
            { game_id: counterStrike2.id, tag_name: "Tactical" },
            { game_id: counterStrike2.id, tag_name: "Multijoueur" },
            { game_id: counterStrike2.id, tag_name: "PvP" },
        ]
    });
    LOST_ARK.grid_id = await prisma.photo.create({
        data: {
            url: LOST_ARK.grid,
        },
        select: { id: true }
    });
    LOST_ARK.banner_id = await prisma.photo.create({
        data: {
            url: LOST_ARK.banner,
        },
        select: { id: true }
    });
    LOST_ARK.logo_id = await prisma.photo.create({
        data: {
            url: LOST_ARK.logo,
        },
        select: { id: true }
    });
    const lostArk = await prisma.game.create({
        data: {
            name: "Lost Ark",
            studio: "Smilegate RPG",
            publisher: "Amazon Games",
            description: "Lost Ark is a free-to-play action MMORPG developed by Smilegate RPG and published by Amazon Games in Western markets. The game combines fast-paced combat with the depth of an MMO, featuring multiple character classes, extensive customization options, and a variety of PvE and PvP content. Players embark on an epic journey to find the Lost Ark and save the world from demonic forces. The game features stunning visuals, intricate dungeons, large-scale raids, and a deep progression system. Lost Ark offers both solo and cooperative gameplay experiences, with sailing mechanics, crafting, and housing systems adding to its rich content.",
            release_date: new Date("2022-02-11"),
            platforms: "PC",
            grid_id: LOST_ARK.grid_id.id,
            banner_id: LOST_ARK.banner_id.id,
            logo_id: LOST_ARK.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(lostArk.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: lostArk.id, tag_name: "RPG" },
            { game_id: lostArk.id, tag_name: "Action" },
            { game_id: lostArk.id, tag_name: "Multijoueur" },
            { game_id: lostArk.id, tag_name: "Co-op" },
        ]
    });
    MARIO_KART_8.grid_id = await prisma.photo.create({
        data: {
            url: MARIO_KART_8.grid,
        },
        select: { id: true }
    });
    MARIO_KART_8.banner_id = await prisma.photo.create({
        data: {
            url: MARIO_KART_8.banner,
        },
        select: { id: true }
    });
    MARIO_KART_8.logo_id = await prisma.photo.create({
        data: {
            url: MARIO_KART_8.logo,
        },
        select: { id: true }
    });
    const marioKart8 = await prisma.game.create({
        data: {
            name: "Mario Kart 8 Deluxe",
            studio: "Nintendo EPD",
            publisher: "Nintendo",
            description: "Mario Kart 8 Deluxe is a racing game developed and published by Nintendo for the Nintendo Switch. It is an enhanced version of Mario Kart 8, originally released for the Wii U. The game features all the tracks, characters, and DLC from the original, plus new characters, kart parts, and gameplay features. Players race on colorful tracks filled with power-ups, shortcuts, and anti-gravity sections that allow driving on walls and ceilings. Mario Kart 8 Deluxe supports local and online multiplayer, offering various game modes including Grand Prix, Time Trials, Battle Mode, and more. It's beloved for its accessible yet competitive gameplay.",
            release_date: new Date("2017-04-28"),
            platforms: "Nintendo Switch",
            grid_id: MARIO_KART_8.grid_id.id,
            banner_id: MARIO_KART_8.banner_id.id,
            logo_id: MARIO_KART_8.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(marioKart8.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: marioKart8.id, tag_name: "Sports" },
            { game_id: marioKart8.id, tag_name: "Multijoueur" },
            { game_id: marioKart8.id, tag_name: "PvP" },
        ]
    });
    WORLD_OF_WARCRAFT.grid_id = await prisma.photo.create({
        data: {
            url: WORLD_OF_WARCRAFT.grid,
        },
        select: { id: true }
    });
    WORLD_OF_WARCRAFT.banner_id = await prisma.photo.create({
        data: {
            url: WORLD_OF_WARCRAFT.banner,
        },
        select: { id: true }
    });
    WORLD_OF_WARCRAFT.logo_id = await prisma.photo.create({
        data: {
            url: WORLD_OF_WARCRAFT.logo,
        },
        select: { id: true }
    });
    const wow = await prisma.game.create({
        data: {
            name: "World of Warcraft",
            studio: "Blizzard Entertainment",
            publisher: "Blizzard Entertainment",
            description: "World of Warcraft (WoW) is a massively multiplayer online role-playing game (MMORPG) developed and published by Blizzard Entertainment. Set in the fantasy world of Azeroth, players create characters and explore vast continents, complete quests, fight monsters, and interact with thousands of other players. The game features multiple playable races and classes, each with unique abilities and playstyles. WoW offers both PvE content including dungeons, raids, and world events, as well as PvP battlegrounds and arenas. With numerous expansions released over the years, World of Warcraft remains one of the most popular and influential MMORPGs in gaming history.",
            release_date: new Date("2004-11-23"),
            platforms: "PC, Mac",
            grid_id: WORLD_OF_WARCRAFT.grid_id.id,
            banner_id: WORLD_OF_WARCRAFT.banner_id.id,
            logo_id: WORLD_OF_WARCRAFT.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(wow.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: wow.id, tag_name: "RPG" },
            { game_id: wow.id, tag_name: "Multijoueur" },
            { game_id: wow.id, tag_name: "Co-op" },
            { game_id: wow.id, tag_name: "PvP" },
        ]
    });
    YOMI_HUSTLE.grid_id = await prisma.photo.create({
        data: {
            url: YOMI_HUSTLE.grid,
        },
        select: { id: true }
    });
    YOMI_HUSTLE.banner_id = await prisma.photo.create({
        data: {
            url: YOMI_HUSTLE.banner,
        },
        select: { id: true }
    });
    YOMI_HUSTLE.logo_id = await prisma.photo.create({
        data: {
            url: YOMI_HUSTLE.logo,
        },
        select: { id: true }
    });
    const yomiHustle = await prisma.game.create({
        data: {
            name: "Your Only Move Is HUSTLE",
            studio: "Ivy Sly",
            publisher: "Ivy Sly",
            description: "Your Only Move Is HUSTLE (YOMI Hustle) is a unique fighting game that combines turn-based strategy with real-time combat. Developed by indie developer Ivy Sly, this innovative title allows players to plan their moves frame-by-frame during a planning phase, then watch the action play out in real-time. This creates a chess-like mind game where players must predict their opponent's actions while setting up their own combos and strategies. The game features a variety of characters with distinct movesets, online multiplayer, and a replay system that lets players analyze every decision. YOMI Hustle has gained a dedicated following for its creative gameplay mechanics.",
            release_date: new Date("2023-08-15"),
            platforms: "PC",
            grid_id: YOMI_HUSTLE.grid_id.id,
            banner_id: YOMI_HUSTLE.banner_id.id,
            logo_id: YOMI_HUSTLE.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(yomiHustle.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: yomiHustle.id, tag_name: "Action" },
            { game_id: yomiHustle.id, tag_name: "Stratégie" },
            { game_id: yomiHustle.id, tag_name: "Indie" },
            { game_id: yomiHustle.id, tag_name: "PvP" },
        ]
    });
    CLAIR_OBSCURE.grid_id = await prisma.photo.create({
        data: {
            url: CLAIR_OBSCURE.grid,
        },
        select: { id: true }
    });
    CLAIR_OBSCURE.banner_id = await prisma.photo.create({
        data: {
            url: CLAIR_OBSCURE.banner,
        },
        select: { id: true }
    });
    CLAIR_OBSCURE.logo_id = await prisma.photo.create({
        data: {
            url: CLAIR_OBSCURE.logo,
        },
        select: { id: true }
    });
    const clairObscure = await prisma.game.create({
        data: {
            name: "Clair Obscure: Expedition 33",
            studio: "Spiders",
            publisher: "EA",
            description: "Clair Obscure: Expedition 33 is an action RPG developed by French studio Spiders and published by EA. The game features a solo campaign with dark and mysterious atmosphere, combining real-time combat with a gripping narrative. Players embark on a perilous expedition into a cursed land shrouded in an ever-approaching darkness. With challenging boss fights, intricate environments, and a richly developed story, Clair Obscure delivers a unique blend of souls-like combat difficulty and immersive storytelling.",
            release_date: new Date("2024-04-09"),
            platforms: "PC, PS5, Xbox Series X/S",
            grid_id: CLAIR_OBSCURE.grid_id.id,
            banner_id: CLAIR_OBSCURE.banner_id.id,
            logo_id: CLAIR_OBSCURE.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(clairObscure.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: clairObscure.id, tag_name: "Action" },
            { game_id: clairObscure.id, tag_name: "RPG" },
            { game_id: clairObscure.id, tag_name: "Adventure" },
            { game_id: clairObscure.id, tag_name: "Difficile" },
        ]
    });
    DRAGON_DOGMA_ONLINE.grid_id = await prisma.photo.create({
        data: {
            url: DRAGON_DOGMA_ONLINE.grid,
        },
        select: { id: true }
    });
    DRAGON_DOGMA_ONLINE.banner_id = await prisma.photo.create({
        data: {
            url: DRAGON_DOGMA_ONLINE.banner,
        },
        select: { id: true }
    });
    DRAGON_DOGMA_ONLINE.logo_id = await prisma.photo.create({
        data: {
            url: DRAGON_DOGMA_ONLINE.logo,
        },
        select: { id: true }
    });
    const dragonDogmaOnline = await prisma.game.create({
        data: {
            name: "Dragon's Dogma Online",
            studio: "Capcom",
            publisher: "Capcom",
            description: "Dragon's Dogma Online is an action MMORPG developed and published by Capcom. Set in a vast fantasy world, players create characters and explore dangerous landscapes filled with epic creatures and thrilling combat encounters. The game features real-time action combat where players can climb on massive monsters, form parties with AI companions called Pawns, and engage in both PvE quests and multiplayer adventures. Dragon's Dogma Online combines dungeon exploration, boss battles, and character progression with a strong focus on cooperative gameplay.",
            release_date: new Date("2015-05-27"),
            platforms: "PC, PS4",
            grid_id: DRAGON_DOGMA_ONLINE.grid_id.id,
            banner_id: DRAGON_DOGMA_ONLINE.banner_id.id,
            logo_id: DRAGON_DOGMA_ONLINE.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(dragonDogmaOnline.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: dragonDogmaOnline.id, tag_name: "RPG" },
            { game_id: dragonDogmaOnline.id, tag_name: "Action" },
            { game_id: dragonDogmaOnline.id, tag_name: "Multijoueur" },
            { game_id: dragonDogmaOnline.id, tag_name: "Co-op" },
        ]
    });

    // Apex Legends
    APEX_LEGENDS.grid_id = await prisma.photo.create({ data: { url: APEX_LEGENDS.grid }, select: { id: true } });
    APEX_LEGENDS.banner_id = await prisma.photo.create({ data: { url: APEX_LEGENDS.banner }, select: { id: true } });
    APEX_LEGENDS.logo_id = await prisma.photo.create({ data: { url: APEX_LEGENDS.logo }, select: { id: true } });
    const apex = await prisma.game.create({
        data: {
            name: "Apex Legends",
            studio: "Respawn Entertainment",
            publisher: "Electronic Arts",
            description: "Apex Legends is a free-to-play hero shooter battle royale from Respawn. Squad up as unique Legends with tactical abilities and fight to be the last team standing across dynamic maps and limited-time modes.",
            release_date: new Date("2019-02-04"),
            platforms: "PC, PS4, PS5, Xbox One, Xbox Series X/S, Nintendo Switch",
            grid_id: APEX_LEGENDS.grid_id.id,
            banner_id: APEX_LEGENDS.banner_id.id,
            logo_id: APEX_LEGENDS.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(apex.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: apex.id, tag_name: "Battle Royale" },
            { game_id: apex.id, tag_name: "Hero Shooter" },
            { game_id: apex.id, tag_name: "FPS" },
            { game_id: apex.id, tag_name: "Multijoueur" },
            { game_id: apex.id, tag_name: "PvP" },
            { game_id: apex.id, tag_name: "Tactical Shooter" },
            { game_id: apex.id, tag_name: "Esports" },
        ]
    });

    // Bloodborne
    BLOODBORNE.grid_id = await prisma.photo.create({ data: { url: BLOODBORNE.grid }, select: { id: true } });
    BLOODBORNE.banner_id = await prisma.photo.create({ data: { url: BLOODBORNE.banner }, select: { id: true } });
    BLOODBORNE.logo_id = await prisma.photo.create({ data: { url: BLOODBORNE.logo }, select: { id: true } });
    const bloodborne = await prisma.game.create({
        data: {
            name: "Bloodborne",
            studio: "FromSoftware",
            publisher: "Sony Computer Entertainment",
            description: "Bloodborne is a gothic action RPG from FromSoftware. Hunt nightmarish beasts through the ancient city of Yharnam with fast, aggressive combat and deep lore.",
            release_date: new Date("2015-03-24"),
            platforms: "PS4",
            grid_id: BLOODBORNE.grid_id.id,
            banner_id: BLOODBORNE.banner_id.id,
            logo_id: BLOODBORNE.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(bloodborne.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: bloodborne.id, tag_name: "Soulslike" },
            { game_id: bloodborne.id, tag_name: "Action" },
            { game_id: bloodborne.id, tag_name: "RPG" },
            { game_id: bloodborne.id, tag_name: "Difficile" },
            { game_id: bloodborne.id, tag_name: "Story-Rich" },
            { game_id: bloodborne.id, tag_name: "Horreur" },
        ]
    });

    // Civilization VI
    CIV_VI.grid_id = await prisma.photo.create({ data: { url: CIV_VI.grid }, select: { id: true } });
    CIV_VI.banner_id = await prisma.photo.create({ data: { url: CIV_VI.banner }, select: { id: true } });
    CIV_VI.logo_id = await prisma.photo.create({ data: { url: CIV_VI.logo }, select: { id: true } });
    const civ6 = await prisma.game.create({
        data: {
            name: "Sid Meier's Civilization VI",
            studio: "Firaxis Games",
            publisher: "2K",
            description: "Civilization VI is a turn-based 4X strategy game where you build an empire to stand the test of time—expand, research, negotiate, and wage wars across eras.",
            release_date: new Date("2016-10-21"),
            platforms: "PC, Mac, Linux, PS4, Xbox One, Nintendo Switch, iOS",
            grid_id: CIV_VI.grid_id.id,
            banner_id: CIV_VI.banner_id.id,
            logo_id: CIV_VI.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(civ6.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: civ6.id, tag_name: "Stratégie" },
            { game_id: civ6.id, tag_name: "Turn-Based" },
            { game_id: civ6.id, tag_name: "4X" },
            { game_id: civ6.id, tag_name: "Singleplayer" },
            { game_id: civ6.id, tag_name: "Multijoueur" },
        ]
    });

    // Dark Souls 3
    DARK_SOULS_3.grid_id = await prisma.photo.create({ data: { url: DARK_SOULS_3.grid }, select: { id: true } });
    DARK_SOULS_3.banner_id = await prisma.photo.create({ data: { url: DARK_SOULS_3.banner }, select: { id: true } });
    DARK_SOULS_3.logo_id = await prisma.photo.create({ data: { url: DARK_SOULS_3.logo }, select: { id: true } });
    const ds3 = await prisma.game.create({
        data: {
            name: "Dark Souls III",
            studio: "FromSoftware",
            publisher: "Bandai Namco Entertainment",
            description: "Dark Souls III continues the challenging action RPG saga with punishing combat, intricate level design, and haunting storytelling woven through item lore and boss encounters.",
            release_date: new Date("2016-03-24"),
            platforms: "PC, PS4, Xbox One",
            grid_id: DARK_SOULS_3.grid_id.id,
            banner_id: DARK_SOULS_3.banner_id.id,
            logo_id: DARK_SOULS_3.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(ds3.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: ds3.id, tag_name: "Soulslike" },
            { game_id: ds3.id, tag_name: "Action" },
            { game_id: ds3.id, tag_name: "RPG" },
            { game_id: ds3.id, tag_name: "Difficile" },
            { game_id: ds3.id, tag_name: "Story-Rich" },
            { game_id: ds3.id, tag_name: "Fantasy" },
        ]
    });

    // Elden Ring
    ELDEN_RING.grid_id = await prisma.photo.create({ data: { url: ELDEN_RING.grid }, select: { id: true } });
    ELDEN_RING.banner_id = await prisma.photo.create({ data: { url: ELDEN_RING.banner }, select: { id: true } });
    ELDEN_RING.logo_id = await prisma.photo.create({ data: { url: ELDEN_RING.logo }, select: { id: true } });
    const elden = await prisma.game.create({
        data: {
            name: "Elden Ring",
            studio: "FromSoftware",
            publisher: "Bandai Namco Entertainment",
            description: "Elden Ring blends open-world exploration with FromSoftware's signature challenging combat. Traverse the Lands Between, uncovering dungeons, bosses, and a deep fantasy narrative.",
            release_date: new Date("2022-02-25"),
            platforms: "PC, PS4, PS5, Xbox One, Xbox Series X/S",
            grid_id: ELDEN_RING.grid_id.id,
            banner_id: ELDEN_RING.banner_id.id,
            logo_id: ELDEN_RING.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(elden.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: elden.id, tag_name: "Soulslike" },
            { game_id: elden.id, tag_name: "Action" },
            { game_id: elden.id, tag_name: "RPG" },
            { game_id: elden.id, tag_name: "Open-World" },
            { game_id: elden.id, tag_name: "Difficile" },
            { game_id: elden.id, tag_name: "Fantasy" },
            { game_id: elden.id, tag_name: "Story-Rich" },
        ]
    });

    // Enlisted
    ENLISTED.grid_id = await prisma.photo.create({ data: { url: ENLISTED.grid }, select: { id: true } });
    ENLISTED.banner_id = await prisma.photo.create({ data: { url: ENLISTED.banner }, select: { id: true } });
    ENLISTED.logo_id = await prisma.photo.create({ data: { url: ENLISTED.logo }, select: { id: true } });
    const enlisted = await prisma.game.create({
        data: {
            name: "Enlisted",
            studio: "Darkflow Software",
            publisher: "Gaijin Entertainment",
            description: "Enlisted is a squad-based MMO shooter set in World War II. Command your squad, switch soldiers on the fly, and fight large-scale battles with realistic weaponry and vehicles.",
            release_date: new Date("2021-03-10"),
            platforms: "PC, PS5, Xbox Series X/S",
            grid_id: ENLISTED.grid_id.id,
            banner_id: ENLISTED.banner_id.id,
            logo_id: ENLISTED.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(enlisted.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: enlisted.id, tag_name: "FPS" },
            { game_id: enlisted.id, tag_name: "MMO" },
            { game_id: enlisted.id, tag_name: "Tactical Shooter" },
            { game_id: enlisted.id, tag_name: "Simulation" },
            { game_id: enlisted.id, tag_name: "PvP" },
            { game_id: enlisted.id, tag_name: "Co-op" },
        ]
    });

    // Final Fantasy XIV Online
    FFXIV.grid_id = await prisma.photo.create({ data: { url: FFXIV.grid }, select: { id: true } });
    FFXIV.banner_id = await prisma.photo.create({ data: { url: FFXIV.banner }, select: { id: true } });
    FFXIV.logo_id = await prisma.photo.create({ data: { url: FFXIV.logo }, select: { id: true } });
    const ffxiv = await prisma.game.create({
        data: {
            name: "Final Fantasy XIV Online",
            studio: "Square Enix",
            publisher: "Square Enix",
            description: "FFXIV is a critically acclaimed MMORPG set in Eorzea. Experience an epic story, deep jobs system, raids, and a welcoming community.",
            release_date: new Date("2013-08-27"),
            platforms: "PC, PS4, PS5",
            grid_id: FFXIV.grid_id.id,
            banner_id: FFXIV.banner_id.id,
            logo_id: FFXIV.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(ffxiv.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: ffxiv.id, tag_name: "MMORPG" },
            { game_id: ffxiv.id, tag_name: "RPG" },
            { game_id: ffxiv.id, tag_name: "Fantasy" },
            { game_id: ffxiv.id, tag_name: "Co-op" },
            { game_id: ffxiv.id, tag_name: "PvP" },
            { game_id: ffxiv.id, tag_name: "Story-Rich" },
        ]
    });

    // Fire Emblem: Three Houses
    FIRE_EMBLEM_THREE_HOUSES.grid_id = await prisma.photo.create({ data: { url: FIRE_EMBLEM_THREE_HOUSES.grid }, select: { id: true } });
    FIRE_EMBLEM_THREE_HOUSES.banner_id = await prisma.photo.create({ data: { url: FIRE_EMBLEM_THREE_HOUSES.banner }, select: { id: true } });
    FIRE_EMBLEM_THREE_HOUSES.logo_id = await prisma.photo.create({ data: { url: FIRE_EMBLEM_THREE_HOUSES.logo }, select: { id: true } });
    const fe3h = await prisma.game.create({
        data: {
            name: "Fire Emblem: Three Houses",
            studio: "Intelligent Systems / Koei Tecmo",
            publisher: "Nintendo",
            description: "A tactical RPG where you lead students through turn-based battles and branching stories across the continent of Fódlan.",
            release_date: new Date("2019-07-26"),
            platforms: "Nintendo Switch",
            grid_id: FIRE_EMBLEM_THREE_HOUSES.grid_id.id,
            banner_id: FIRE_EMBLEM_THREE_HOUSES.banner_id.id,
            logo_id: FIRE_EMBLEM_THREE_HOUSES.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(fe3h.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: fe3h.id, tag_name: "Tactical RPG" },
            { game_id: fe3h.id, tag_name: "Turn-Based" },
            { game_id: fe3h.id, tag_name: "Story-Rich" },
            { game_id: fe3h.id, tag_name: "Singleplayer" },
            { game_id: fe3h.id, tag_name: "Fantasy" },
        ]
    });

    // Fortnite
    FORTNITE.grid_id = await prisma.photo.create({ data: { url: FORTNITE.grid }, select: { id: true } });
    FORTNITE.banner_id = await prisma.photo.create({ data: { url: FORTNITE.banner }, select: { id: true } });
    FORTNITE.logo_id = await prisma.photo.create({ data: { url: FORTNITE.logo }, select: { id: true } });
    const fortnite = await prisma.game.create({
        data: {
            name: "Fortnite",
            studio: "Epic Games",
            publisher: "Epic Games",
            description: "Fortnite features Battle Royale and Creative modes—build structures, compete in large PvP matches, or craft your own experiences.",
            release_date: new Date("2017-09-26"),
            platforms: "PC, Mac, PS4, PS5, Xbox One, Xbox Series X/S, Nintendo Switch, Mobile",
            grid_id: FORTNITE.grid_id.id,
            banner_id: FORTNITE.banner_id.id,
            logo_id: FORTNITE.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(fortnite.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: fortnite.id, tag_name: "Battle Royale" },
            { game_id: fortnite.id, tag_name: "Shooter" },
            { game_id: fortnite.id, tag_name: "Multijoueur" },
            { game_id: fortnite.id, tag_name: "PvP" },
            { game_id: fortnite.id, tag_name: "Creative" },
            { game_id: fortnite.id, tag_name: "Building" },
            { game_id: fortnite.id, tag_name: "Sandbox" },
        ]
    });

    // Guild Wars 2
    GUILD_WARS_2.grid_id = await prisma.photo.create({ data: { url: GUILD_WARS_2.grid }, select: { id: true } });
    GUILD_WARS_2.banner_id = await prisma.photo.create({ data: { url: GUILD_WARS_2.banner }, select: { id: true } });
    GUILD_WARS_2.logo_id = await prisma.photo.create({ data: { url: GUILD_WARS_2.logo }, select: { id: true } });
    const gw2 = await prisma.game.create({
        data: {
            name: "Guild Wars 2",
            studio: "ArenaNet",
            publisher: "NCSoft",
            description: "Guild Wars 2 is a dynamic MMORPG with world events, flexible builds, and story-driven content across the fantasy realm of Tyria.",
            release_date: new Date("2012-08-28"),
            platforms: "PC",
            grid_id: GUILD_WARS_2.grid_id.id,
            banner_id: GUILD_WARS_2.banner_id.id,
            logo_id: GUILD_WARS_2.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(gw2.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: gw2.id, tag_name: "MMORPG" },
            { game_id: gw2.id, tag_name: "RPG" },
            { game_id: gw2.id, tag_name: "Fantasy" },
            { game_id: gw2.id, tag_name: "Co-op" },
            { game_id: gw2.id, tag_name: "PvP" },
            { game_id: gw2.id, tag_name: "Story-Rich" },
        ]
    });

    // Hades
    HADES.grid_id = await prisma.photo.create({ data: { url: HADES.grid }, select: { id: true } });
    HADES.banner_id = await prisma.photo.create({ data: { url: HADES.banner }, select: { id: true } });
    HADES.logo_id = await prisma.photo.create({ data: { url: HADES.logo }, select: { id: true } });
    const hades = await prisma.game.create({
        data: {
            name: "Hades",
            studio: "Supergiant Games",
            publisher: "Supergiant Games",
            description: "Battle out of the Underworld in this award-winning roguelike with rich narrative, tight combat, and striking isometric art.",
            release_date: new Date("2020-09-17"),
            platforms: "PC, Nintendo Switch, PS4, PS5, Xbox One, Xbox Series X/S",
            grid_id: HADES.grid_id.id,
            banner_id: HADES.banner_id.id,
            logo_id: HADES.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(hades.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: hades.id, tag_name: "Roguelike" },
            { game_id: hades.id, tag_name: "Indie" },
            { game_id: hades.id, tag_name: "Action" },
            { game_id: hades.id, tag_name: "Isometric" },
            { game_id: hades.id, tag_name: "Story-Rich" },
        ]
    });

    // Minecraft
    MINECRAFT.grid_id = await prisma.photo.create({ data: { url: MINECRAFT.grid }, select: { id: true } });
    MINECRAFT.banner_id = await prisma.photo.create({ data: { url: MINECRAFT.banner }, select: { id: true } });
    MINECRAFT.logo_id = await prisma.photo.create({ data: { url: MINECRAFT.logo }, select: { id: true } });
    const minecraft = await prisma.game.create({
        data: {
            name: "Minecraft",
            studio: "Mojang Studios",
            publisher: "Mojang Studios",
            description: "Minecraft is a sandbox game about placing blocks and going on adventures. Survive, build, craft, and create in infinite worlds.",
            release_date: new Date("2011-11-18"),
            platforms: "PC, Mac, PS4, PS5, Xbox One, Xbox Series X/S, Nintendo Switch, Mobile",
            grid_id: MINECRAFT.grid_id.id,
            banner_id: MINECRAFT.banner_id.id,
            logo_id: MINECRAFT.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(minecraft.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: minecraft.id, tag_name: "Sandbox" },
            { game_id: minecraft.id, tag_name: "Survival" },
            { game_id: minecraft.id, tag_name: "Building" },
            { game_id: minecraft.id, tag_name: "Crafting" },
            { game_id: minecraft.id, tag_name: "Creative" },
            { game_id: minecraft.id, tag_name: "Co-op" },
            { game_id: minecraft.id, tag_name: "Multijoueur" },
        ]
    });

    // Mount & Blade II: Bannerlord
    MOUNT_BLADE_2.grid_id = await prisma.photo.create({ data: { url: MOUNT_BLADE_2.grid }, select: { id: true } });
    MOUNT_BLADE_2.banner_id = await prisma.photo.create({ data: { url: MOUNT_BLADE_2.banner }, select: { id: true } });
    MOUNT_BLADE_2.logo_id = await prisma.photo.create({ data: { url: MOUNT_BLADE_2.logo }, select: { id: true } });
    const bannerlord = await prisma.game.create({
        data: {
            name: "Mount & Blade II: Bannerlord",
            studio: "TaleWorlds Entertainment",
            publisher: "TaleWorlds Entertainment",
            description: "Bannerlord is a medieval sandbox combining grand strategy with action RPG battles, sieges, and kingdom building.",
            release_date: new Date("2022-10-25"),
            platforms: "PC, PS4, PS5, Xbox One, Xbox Series X/S",
            grid_id: MOUNT_BLADE_2.grid_id.id,
            banner_id: MOUNT_BLADE_2.banner_id.id,
            logo_id: MOUNT_BLADE_2.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(bannerlord.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: bannerlord.id, tag_name: "Stratégie" },
            { game_id: bannerlord.id, tag_name: "RPG" },
            { game_id: bannerlord.id, tag_name: "Sandbox" },
            { game_id: bannerlord.id, tag_name: "Medieval" },
            { game_id: bannerlord.id, tag_name: "Simulation" },
        ]
    });

    // Overwatch 2
    OVERWATCH_2.grid_id = await prisma.photo.create({ data: { url: OVERWATCH_2.grid }, select: { id: true } });
    OVERWATCH_2.banner_id = await prisma.photo.create({ data: { url: OVERWATCH_2.banner }, select: { id: true } });
    OVERWATCH_2.logo_id = await prisma.photo.create({ data: { url: OVERWATCH_2.logo }, select: { id: true } });
    const ow2 = await prisma.game.create({
        data: {
            name: "Overwatch 2",
            studio: "Blizzard Entertainment",
            publisher: "Blizzard Entertainment",
            description: "A team-based hero shooter featuring 5v5 competitive play, unique heroes, and global esports.",
            release_date: new Date("2022-10-04"),
            platforms: "PC, PS4, PS5, Xbox One, Xbox Series X/S, Nintendo Switch",
            grid_id: OVERWATCH_2.grid_id.id,
            banner_id: OVERWATCH_2.banner_id.id,
            logo_id: OVERWATCH_2.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(ow2.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: ow2.id, tag_name: "Hero Shooter" },
            { game_id: ow2.id, tag_name: "FPS" },
            { game_id: ow2.id, tag_name: "Multijoueur" },
            { game_id: ow2.id, tag_name: "PvP" },
            { game_id: ow2.id, tag_name: "Esports" },
        ]
    });

    // The Elder Scrolls Online
    TESO.grid_id = await prisma.photo.create({ data: { url: TESO.grid }, select: { id: true } });
    TESO.banner_id = await prisma.photo.create({ data: { url: TESO.banner }, select: { id: true } });
    TESO.logo_id = await prisma.photo.create({ data: { url: TESO.logo }, select: { id: true } });
    const eso = await prisma.game.create({
        data: {
            name: "The Elder Scrolls Online",
            studio: "ZeniMax Online Studios",
            publisher: "Bethesda Softworks",
            description: "TESO is an online Elder Scrolls RPG set in Tamriel with quests, dungeons, PvP, and sprawling fantasy lore.",
            release_date: new Date("2014-04-04"),
            platforms: "PC, Mac, PS4, PS5, Xbox One, Xbox Series X/S",
            grid_id: TESO.grid_id.id,
            banner_id: TESO.banner_id.id,
            logo_id: TESO.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(eso.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: eso.id, tag_name: "MMORPG" },
            { game_id: eso.id, tag_name: "RPG" },
            { game_id: eso.id, tag_name: "Fantasy" },
            { game_id: eso.id, tag_name: "Co-op" },
            { game_id: eso.id, tag_name: "PvP" },
            { game_id: eso.id, tag_name: "Story-Rich" },
        ]
    });

    // Valorant
    VALORANT.grid_id = await prisma.photo.create({ data: { url: VALORANT.grid }, select: { id: true } });
    VALORANT.banner_id = await prisma.photo.create({ data: { url: VALORANT.banner }, select: { id: true } });
    VALORANT.logo_id = await prisma.photo.create({ data: { url: VALORANT.logo }, select: { id: true } });
    const valorant = await prisma.game.create({
        data: {
            name: "VALORANT",
            studio: "Riot Games",
            publisher: "Riot Games",
            description: "VALORANT is a tactical 5v5 FPS with precise gunplay and hero-style abilities, built for competitive play.",
            release_date: new Date("2020-06-02"),
            platforms: "PC",
            grid_id: VALORANT.grid_id.id,
            banner_id: VALORANT.banner_id.id,
            logo_id: VALORANT.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(valorant.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: valorant.id, tag_name: "Tactical Shooter" },
            { game_id: valorant.id, tag_name: "Hero Shooter" },
            { game_id: valorant.id, tag_name: "FPS" },
            { game_id: valorant.id, tag_name: "Multijoueur" },
            { game_id: valorant.id, tag_name: "PvP" },
            { game_id: valorant.id, tag_name: "Esports" },
        ]
    });

    // Kingdom Hearts II
    KINGDOM_HEARTS_2.grid_id = await prisma.photo.create({ data: { url: KINGDOM_HEARTS_2.grid }, select: { id: true } });
    KINGDOM_HEARTS_2.banner_id = await prisma.photo.create({ data: { url: KINGDOM_HEARTS_2.banner }, select: { id: true } });
    KINGDOM_HEARTS_2.logo_id = await prisma.photo.create({ data: { url: KINGDOM_HEARTS_2.logo }, select: { id: true } });
    const kh2 = await prisma.game.create({
        data: {
            name: "Kingdom Hearts II",
            studio: "Square Enix",
            publisher: "Square Enix",
            description: "Kingdom Hearts II is an action JRPG blending Final Fantasy and Disney worlds. Follow Sora, Donald, and Goofy across vibrant realms with real-time combat and a heartfelt, story-rich adventure.",
            release_date: new Date("2006-03-28"),
            platforms: "PS2, PS3, PS4, Xbox One, PC",
            grid_id: KINGDOM_HEARTS_2.grid_id.id,
            banner_id: KINGDOM_HEARTS_2.banner_id.id,
            logo_id: KINGDOM_HEARTS_2.logo_id.id,
            is_approved: true,
        }
    });
    gameIds.push(kh2.id);
    await prisma.game_tag.createMany({
        data: [
            { game_id: kh2.id, tag_name: "JRPG" },
            { game_id: kh2.id, tag_name: "Action" },
            { game_id: kh2.id, tag_name: "RPG" },
            { game_id: kh2.id, tag_name: "Story-Rich" },
            { game_id: kh2.id, tag_name: "Fantasy" },
            { game_id: kh2.id, tag_name: "Singleplayer" },
        ]
    });

    // Collect and return all created game IDs
    return gameIds;
}

export default seedAllGames;